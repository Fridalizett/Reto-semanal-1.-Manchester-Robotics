#!/usr/bin/env python
#from typing import Self

#Este codigo fue complementado y tomando de esqueleto al codigo
# realizado en las clases de Control y Actuadores con el arduino
import rospy
import numpy as np
from pid_control.msg import motor_output
from pid_control.msg import motor_input
from pid_control.msg import set_point


#Setup parameters, variables and callback functions here (if required)

#Definicion de las variables en motor_input.msg
input = motor_input()
input.input = 0.0
input.time = 0.0

#Parametros de control_params.yaml para diferentes valores de entrada
VMotor = rospy.get_param("sp", 0.0)
VMotor1 = rospy.get_param("sp1", 5.0)
VMotor2 = rospy.get_param("sp2", 1.0)
VMotor3 = rospy.get_param("sp3", 8.0)
VMotor4 = rospy.get_param("sp4", 3.0)
VMotor5 = rospy.get_param("sp5", 7.0)
VMotor6 = rospy.get_param("sp6", 7.0)

#Diferentes valores de kp, ki, kd para ver el desempeno del controlador 
kp = rospy.get_param("kp", 2.0)
kp1 = rospy.get_param("kp1", 2.0)
kp2 = rospy.get_param("kp2", 2.0)
kp3 = rospy.get_param("kp3", 2.0)
kp4 = rospy.get_param("kp4", 2.0)
kp5 = rospy.get_param("kp5", 2.0)
kp6 = rospy.get_param("kp6", 2.0)

ki = rospy.get_param("ki", 6.0)
ki1 = rospy.get_param("ki1", 6.0)
ki2 = rospy.get_param("ki2", 6.0)
ki3 = rospy.get_param("ki3", 6.0)
ki4 = rospy.get_param("ki4", 6.0)
ki5 = rospy.get_param("ki5", 6.0)
ki6 = rospy.get_param("ki6", 6.0)

kd = rospy.get_param("kd", 0.03)
kd1 = rospy.get_param("kd1", 0.03)
kd2 = rospy.get_param("kd2", 0.03)
kd3 = rospy.get_param("kd3", 0.03)
kd4 = rospy.get_param("kd4", 0.03)
kd5 = rospy.get_param("kd5", 0.03)
kd6 = rospy.get_param("kd6", 0.03)

#Tiempo de muestreo
Ts = rospy.get_param("Ts", 0.02)

#Definicion de las variables en motor_output.msg
output = motor_output()
output.output = 0.0
output.time = 0.0
output.status = ""


#Calculo de constantes del controlador PID con diferentes situaciones(subamortiguado, criticamente,sobreamortiguado)
K1 = kp + Ts*ki + kd/Ts
K2 = -kp -2.0*kd/Ts
K3 = kd/Ts


u = [0.0, 0.0]        #U es la Matriz de salida del controlador 
e = [0.0, 0.0, 0.0]   #E es la Matriz de error del sistema controlado

#Funcion para definir las variables de salida
def callback(msg) :
  global output 
  output = msg

def callbacksp(msgsp):
  global set_sp
  set_sp = msgsp.outsp

#Stop Condition
def stop():
 #Setup the stop message (can be the same as the control message)
  print("Stopping")

if __name__=='__main__':
    #Initialise and Setup node
    rospy.init_node("controller")
    rate = rospy.Rate(100)
    rospy.on_shutdown(stop)

    #Setup Publishers and subscribers here
    pub = rospy.Publisher("/motor_input", motor_input, queue_size = 1)
    rospy.Subscriber("/motor_output", motor_output, callback)

    rospy.Subscriber("/set_point", set_point, callbacksp)

    print("The Controller is Running")
    #Run the node
    while not rospy.is_shutdown():
        #Write your code here

        #Se muestran las posibles diferentes situaciones(subamortiguado, sobreamortiguado y criticamente amortiguado)
        #Para ello se hizo variar los valores de kp,ki, kd y el voltaje de entrada
        if (output.time < 10):
          e[0] = VMotor - output.output
        if(output.time > 10.1):
          e[0] = VMotor1 - output.output
        if(output.time > 15):
          e[0] = VMotor2 - output.output

          kp2
          ki2
          kd2
          Ts

          K1 = kp2 + Ts*ki2 + kd2/Ts
          K2 = -kp2 -2.0*kd2/Ts
          K3 = kd2/Ts
        if(output.time > 25):
          e[0] = VMotor3 - output.output

          kp3
          ki3
          kd3
          Ts

          K1 = kp3 + Ts*ki3 + kd3/Ts
          K2 = -kp3 -2.0*kd3/Ts
          K3 = kd3/Ts
        if(output.time > 35):
          e[0] = VMotor4 - output.output

          kp4
          ki4
          kd4
          Ts

          K1 = kp4 + Ts*ki4 + kd4/Ts
          K2 = -kp4 -2.0*kd4/Ts
          K3 = kd4/Ts
        #En esta condicion se deja el controlador mal entonado, y en la grafica se ve como queda oscilando
        if(output.time > 45):
          e[0] = VMotor5 - output.output

          kp5
          ki5
          kd5
          Ts

          K1 = kp5 + Ts*ki5 + kd5/Ts
          K2 = -kp5 -2.0*kd5/Ts
          K3 = kd5/Ts
        
        if(output.time > 55):
          e[0] = VMotor6 - output.output

          kp6
          ki6
          kd6
          Ts

          K1 = kp6 + Ts*ki6 + kd6/Ts
          K2 = -kp6 -2.0*kd6/Ts
          K3 = kd6/Ts
        

        u[0] = K1*e[0] + K2*e[1] + K3*e[2] + u[1]
        e[2] = e[1]
        e[1] = e[0]
        u[1] = u[0]

        if (u[0] > 13) : u[0] = 13.0
        if (u[0] < -13) : u[0] = -13.0

        input.input = u[0] * (1.0 / 13.0)

        pub.publish(input)
        print(output.output)

        rate.sleep()